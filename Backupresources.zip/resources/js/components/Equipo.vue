<template>
         <main class="main">
            <!-- Breadcrumb -->
            <ol class="breadcrumb">
                <li class="breadcrumb-item">Home</li>
                <li class="breadcrumb-item"><a href="#">Admin</a></li>
                <li class="breadcrumb-item active">Dashboard</li>
            </ol>
            <div class="container-fluid">
                <!-- Ejemplo de tabla Listado -->
                <div class="card">
                    <div class="card-header">
                        <i class="fa fa-align-justify"></i> Equipment
                        <button type="button" @click="Verdetalle('equipo','registrar')" class="btn btn-secondary">
                            <i class="icon-plus"></i>&nbsp;Generate QR
                        </button>
                    </div>
                    
                    <template v-if="listado==1">
                    <div class="card-body">
                        <div class="form-group row">
                            <div class="col-md-11">
                            <div class="form-group row">
                            <label class="col-md-4 form-control-label" for="nombre">PDSI: </label> 
                            <div class="col-md-5">
                                <input type="text" v-model="bpdsi" @keyup.enter="listarEquipo(1,bpdsi,bempresa,bnumero,bequipo,bmodelo,bserie)" class="form-control" placeholder="PDSI" ></div>
                            <label class="col-md-4 form-control-label" for="nombre">Company: </label> 
                            <div class="col-md-5">
                                <input type="text" v-model="bempresa" @keyup.enter="listarEquipo(1,bpdsi,bempresa,bnumero,bequipo,bmodelo,bserie)" class="form-control" placeholder="Company" ></div>
                            <label class="col-md-4 form-control-label" for="solicitante">Nº Certificate: </label> 
                            <div class="col-md-5">
                                    <input type="text" v-model="bnumero" @keyup.enter="listarEquipo(1,bpdsi,bempresa,bnumero,bequipo,bmodelo,bserie)" class="form-control" placeholder="Nº Certificate"></div>
                            <label class="col-md-4 form-control-label" for="solicitante">Equipment Type: </label> 
                            <div class="col-md-5">
                                    <input type="text" v-model="bequipo" @keyup.enter="listarEquipo(1,bpdsi,bempresa,bnumero,bequipo,bmodelo,bserie)" class="form-control" placeholder="Name Professional"></div>
                            <label class="col-md-4 form-control-label" for="solicitante">Model: </label> 
                            <div class="col-md-5">
                                    <input type="text" v-model="bmodelo" @keyup.enter="listarEquipo(1,bpdsi,bempresa,bnumero,bequipo,bmodelo,bserie)" class="form-control" placeholder="Surname Professional"></div>
                            <label class="col-md-4 form-control-label" for="solicitante">Nº Serie: </label> 
                            <div class="col-md-5">
                                    <input type="text" v-model="bserie" @keyup.enter="listarEquipo(1,bpdsi,bempresa,bnumero,bequipo,bmodelo,bserie)" class="form-control" placeholder="Certificate type"></div>
                                    <button type="submit" @click="listarEquipo(1,bpdsi,bempresa,bnumero,bequipo,bmodelo,bserie)" class="btn btn-primary"><i class="fa fa-search"></i> Search</button>
                            </div> 
                                </div>
                        </div>
                        <table class="table table-bordered table-striped table-sm">
                            <thead>
                                <tr>
                                    <th>Certificate</th>
                                    <th>PDSI</th>
                                    <th>Nº Certificate</th>
                                    <th>Company</th>
                                    <th>Equipment Type</th>
                                    <th>Model</th>
                                    <th>Nº Serie</th>
                                    <th>Date</th>
                                    <th>QR</th>
                                    <th>Expiration date</th>
                                    <th>Status </th>
                                </tr>
                            </thead>
                            <tbody>
                                    <tr v-for="equipos in arrayEquipo" :key="equipos.id">
                                        <td>
                                        <template v-if="equipos.estado==0">
                                            <button type="button" class="btn btn-info btn-sm" @click="activarEquipo(equipos.id)">
                                            <i class="icon-check"></i>
                                            </button> 
                                        </template> 
                                        <template v-if="equipos.estado==1">
                                            <button type="button" @click="Verdetalle('equipo','actualizar',equipos)" class="btn btn-info btn-sm" >
                                            <i class="icon-pencil"></i>
                                            </button> 
                                            
                                            <button type="button" class="btn btn-danger btn-sm" @click="desactivarEquipo(equipos.id)">
                                            <i class="icon-trash"></i>
                                            </button>
                                        </template>                                            
                                    </td>
                                    <td v-html="equipos.pdsi"></td>
                                        <td v-text="equipos.codigo_certificado"></td>
                                    <td v-text="equipos.cliente"></td>
                                    <td v-text="equipos.tipoEquipo"></td>
                                    <td v-text="equipos.marca+' '+equipos.modeloEquipo"></td>
                                    <td v-text="equipos.serie"></td>
                                    <td v-html="equipos.fechaIspeccion"></td>
                                    <td v-text="equipos.fechaRecomendada"></td>
                                    <td>
                                        <figure>
                                            <img width="50" height="50" :src="'/qrcodes/equipo/'+equipos.qr"  name="perfil">
                                        </figure>
                                    </td>
                                    <td> <div v-if="equipos.estado==1">
                                        <span class="badge badge-secondary">Issued</span>
                                        </div>
                                        <div v-else-if="equipos.fechaRecomendada<fechahoy()">
                                        <span class="badge badge-danger">Expired</span>
                                        </div>
                                        <div v-else-if="equipos.estado==0">
                                        <span class="badge badge-secondary">Canceled</span>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        
                        <nav>
                            <ul class="pagination">
                                <li class="page-item" v-if="pagination.current_page > 1">
                                    <a class="page-link" href="#" @click.prevent="cambiarPagina(pagination.current_page - 1,bpdsi,bempresa,bnumero,bequipo,bmodelo,bserie)">Ant</a>
                                </li>
                                <li class="page-item" v-for="page in pagesNumber" :key="page" :class="[page == isActived ? 'active': '']">
                                    <a class="page-link" href="#" @click.prevent="cambiarPagina(page,bpdsi,bempresa,bnumero,bequipo,bmodelo,bserie)" v-text="page"></a>
                                </li>
                                <li class="page-item" v-if="pagination.current_page < pagination.last_page">
                                    <a class="page-link" href="#" @click.prevent="cambiarPagina(pagination.current_page+1,bpdsi,bempresa,bnumero,bequipo,bmodelo,bserie)">Sig</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                    </template>
                    <template v-else-if="listado==0">
                    
                            <!-- Mostrar Datos -->
                    <div class="card-body">
                        <div class="form-group row border">
                            <h2 v-text="tituloModal"></h2>
                        </div>
                        <div class="form-group row border">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="">PDSI:</label>
                                    <input type="text" v-model="pdsi" class="form-control">
                                </div>  
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">Company: </label>
                                    <input type="text" v-model="cliente" class="form-control">
                                </div>  
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="">RUC: </label>
                                    <input type="text" v-model="ruc" class="form-control">
                                </div>  
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for=""># Certificate: </label>
                                    <input type="text" v-model="codigo_certificado" class="form-control">
                                </div>  
                            </div>
                            <div class="col-md-4"> 
                                <div class="form-group">
                                    <label for=""># Report: </label>
                                    <input type="text" v-model="codigo_informe" class="form-control">
                                </div>  
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="">Issue Date: </label>
                                    <input type="date" v-model="fechaEmision" class="form-control">
                                </div> 
                            </div>
                            <div class="col-md-6">
                                    <div class="form-group">
                                    <label for="">Equipment Type: </label>
                                    <input type="text" v-model="tipoEquipo" class="form-control">
                                    </div>
                            </div>
                            <div class="col-md-6">
                                    <div class="form-group">
                                    <label for="">Brand: </label>
                                    <input type="text" v-model="marca" class="form-control">
                                    </div>
                            </div>
                            <div class="col-md-4">
                                    <div class="form-group">
                                    <label for="">Model: </label>
                                    <input type="text" v-model="modeloEquipo" class="form-control">
                                    </div>
                            </div>
                            <div class="col-md-4">
                                    <div class="form-group">
                                    <label for="">Capacity: </label>
                                    <input type="text" v-model="capacidad" class="form-control">
                                    </div>
                            </div>
                            <div class="col-md-4">
                                    <div class="form-group">
                                    <label for="">Serie: </label>
                                    <input type="text" v-model="serie" class="form-control">
                                    </div>
                            </div>
                            <div class="col-md-4">
                                    <div class="form-group">
                                    <label for="">Comment / Observation: </label>
                                    <input type="text" v-model="otro" class="form-control">
                                    </div>
                            </div>
                            <div class="col-md-4">
                                    <div class="form-group">
                                    <label for="">Inspection Date: </label>
                                    <input type="date" v-model="fechaIspeccion" class="form-control">
                                    </div>
                            </div>
                            <div class="col-md-4">
                                    <div class="form-group">
                                    <label for="">Recommended Inspection Date: </label>
                                    <input type="date" v-model="fechaRecomendada" class="form-control">
                                    </div>
                            </div>
                            
                        </div>
                    <div class="form-group row">
                     <button type="button" class="btn btn-danger" @click="MirarResumen()">Cancel</button>&nbsp;&nbsp;
                     <button type="button" v-if="tipoAccion==2" class="btn btn-primary" @click="ActualizarEquipo()">To update</button>&nbsp;&nbsp;
                     <button type="button" v-if="tipoAccion==1" class="btn btn-primary" @click="GuardarEquipo()">Save</button>&nbsp;&nbsp;
                        </div>             
                    </div>
                        </template>
            </div>
                <!-- Fin ejemplo de tabla Listado -->
            </div>
            
            
        </main>
</template>


<script>

import moment from 'moment';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
export default {
    name: 'app',
        data(){
            return{
                //editor de texto
                editor: ClassicEditor,
                editorData: '<p>Content of the editor.</p>',
                editorConfig: {
                    },
                //Equipo
                idequipo:'',
                codigo_certificado:'',
                codigo_informe:'',
                fechaIspeccion:'',
                fechaRecomendada:'',
                fechaEmision:'',
                tipoEquipo:'',
                marca:'',
                modeloEquipo:'',
                serie:'',
                capacidad:'',
                ruc:'',
                cliente:'',
                pdsi:'',
                otro:'',

                //buscar
                bpdsi:'',
                bempresa:'',
                bnumero:'',
                bequipo:'',
                bmodelo:'',
                bserie:'',

                //
                arrayEquipo: [],
                
                modal : 0,
                tituloModal:'',
                tipoAccion : 0 ,
                listado: 1,
                errorRevision : 0,
                errorMostrarMsjRevision : [],
                pagination : {
                'total'          : 0,
                'current_page'   : 0,
                'per_page'       : 0,
                'last_page'      : 0,
                'from'           : 0,
                'to'             : 0,
                },
                offset : 3,
                criterio : 'revalidacion',
                buscar :''
            }

        },
        computed:{
            isActived: function(){
                return this.pagination.current_page;
            },
            //calcula los elementos de la paginacion 
            pagesNumber: function(){
                    if(!this.pagination.to){
                        return [];
                    }
                    var from = this.pagination.current_page - this.offset;
                    if(from < 1) {
                        from = 1;
                    }
                    var to = from + (this.offset * 2);
                    if(to >= this.pagination.last_page) {
                        to = this.pagination.last_page;
                    }
                    var pagesArray =[];
                    while(from <=  to){
                        pagesArray.push(from);
                        from++;
                    }
                    return pagesArray;
            }
        },
        methods : {
            listarEquipo(page,bpdsi,bempresa,bnumero,bequipo,bmodelo,bserie){
                let me=this;
                var url= '/equipo?page=' + page + '&bpdsi='+ bpdsi+ '&bempresa='+ bempresa
                + '&bnumero='+ bnumero+ '&bequipo='+ bequipo + '&bmodelo='+ bmodelo+ '&bserie='+ bserie;
                axios.get(url).then(function (response) {
                    var respuesta= response.data;
                    me.arrayEquipo = respuesta.equipos.data;
                    me.pagination= respuesta.pagination;
                })
                .catch(function (error) {
                    // handle error
                    console.log(error);
                });
            },
            
            GuardarEquipo(){
                let me = this;
                    axios.put('/equipo/registrar',
                    {
                        'codigo_certificado': this.codigo_certificado,
                        'codigo_informe': this.codigo_informe,
                        'fechaIspeccion': this.fechaIspeccion,
                        'fechaRecomendada': this.fechaRecomendada,
                        'fechaEmision': this.fechaEmision,
                        'tipoEquipo': this.tipoEquipo,
                        'marca': this.marca,
                        'modeloEquipo': this.modeloEquipo,
                        'serie': this.serie,
                        'capacidad': this.capacidad,
                        'ruc':this.ruc,
                        'cliente':this.cliente,
                        'pdsi':this.pdsi,
                        'otro':this.otro,                       
                    }).then(function (response) {
                        me.listarEquipo(1,'','','','','','');
                    
                }).catch(function (error) {
                    // handle error
                    console.log(error);
                });
                this.listado=1;
            },
            ActualizarEquipo(){
                let me = this;
                    axios.put('/equipo/actualizar',
                    {
                        'id': this.idequipo,
                        'codigo_certificado': this.codigo_certificado,
                        'codigo_informe': this.codigo_informe,
                        'fechaIspeccion': this.fechaIspeccion,
                        'fechaRecomendada': this.fechaRecomendada,
                        'fechaEmision': this.fechaEmision,
                        'tipoEquipo': this.tipoEquipo,
                        'marca': this.marca,
                        'modeloEquipo': this.modeloEquipo,
                        'serie': this.serie,
                        'capacidad': this.capacidad,
                        'ruc':this.ruc,
                        'cliente':this.cliente,
                        'pdsi':this.pdsi,
                        'otro':this.otro,                        
                    }).then(function (response) {
                        me.cerrarModal();
                        me.listarEquipo(1,'','','','','','');
                    
                }).catch(function (error) {
                    // handle error
                    console.log(error);
                });
                this.listado=1;
            },
            cerrarModal(){
                    this.modal = 0;
                    this.tituloModal = '';
                    this.idusuario= '';
            },
            fecha(d){
                return moment(d).format("YYYY-MM-DD");
            },
            fechahoy(){
                return moment().format("YYYY-MM-DD");
            },

            MirarResumen(){
                this.listado=1;
                this.idequipo='';
                this.codigo_certificado='';
                this.codigo_informe='';
                this.fechaIspeccion='';
                this.fechaRecomendada='';
                this.fechaEmision='';
                this.tipoEquipo='';
                this.marca='';
                this.modeloEquipo='';
                this.serie='';
                this.capacidad='';
                this.ruc='';
                this.cliente='';
                this.pdsi='';
                this.otro='';
            },
            fecha (d){
                return moment(d).format("YYYY-MM-DD");
            },
            cambiarPagina(page,bpdsi,bempresa,bnumero,bequipo,bmodelo,bserie){
                let me = this;
                //Actualiza la pagina actual
                me.pagination.current_page = page;
                //envia peticion para visualizar la data de esa pagina 
                me.listarEquipo(page,bpdsi,bempresa,bnumero,bequipo,bmodelo,bserie);
            },
                        
            validarRevision(){
                    this.errorRevision=0;
                    this.errorMostrarMsjRevision =[];

                    if(!this.idusuario) this.errorMostrarMsjRevision.push("It cant be empty.");
                    if(this.errorMostrarMsjRevision.length) this.errorRevision = 1;
                    return this.errorRevision;
           
            },
            desactivarEquipo(id){
                const swalWithBootstrapButtons = Swal.mixin({
                customClass: {
                    confirmButton: 'btn btn-success',
                    cancelButton: 'btn btn-danger'
                },
                buttonsStyling: false
                })

                swalWithBootstrapButtons.fire({
                title: 'Are you sure to deactivate this Equipment?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'To accept',
                cancelButtonText: 'Cancel',
                reverseButtons: true
                }).then((result) => {
                if (result.value) {
                    let me=this;
                    axios.put('/equipo/desactivar',{
                    'id': id
                    }).then(function (response){
                    me.listarEquipo(1,'','','','','','');
                     swalWithBootstrapButtons.fire(
                    'Disabled',
                    'Registration has been successfully deactivated.',
                    'success'
                    )
                })
                .catch(function (error){
                    console.log(error);
                });
                   
                } else if (
                    /* Read more about handling dismissals below */
                    result.dismiss === Swal.DismissReason.cancel
                ) {
                    
                }
                })
            },
            activarEquipo(id){
                const swalWithBootstrapButtons = Swal.mixin({
                customClass: {
                    confirmButton: 'btn btn-success',
                    cancelButton: 'btn btn-danger'
                },
                buttonsStyling: false
                })

                swalWithBootstrapButtons.fire({
                title: 'Are you sure to activate this Equipment?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'To accept',
                cancelButtonText: 'Cancel',
                reverseButtons: true
                }).then((result) => {
                if (result.value) {
                    let me=this;
                    axios.put('/equipo/activar',{
                    'id': id
                    }).then(function (response){
                    me.listarEquipo(1,'','','','','','');
                     swalWithBootstrapButtons.fire(
                    'Activated',
                    'Registration has been activated successfully.',
                    'success'
                    )
                })
                .catch(function (error){
                    console.log(error);
                });
                   
                } else if (
                    /* Read more about handling dismissals below */
                    result.dismiss === Swal.DismissReason.cancel
                ) {
                    
                }
                })
            },
            Verdetalle(modelo, accion, data = []){
                this.listado=0;
                switch(modelo){
                    case "equipo":
                        {
                            switch(accion){
                                case 'registrar':
                                {
                                    this.tituloModal = 'Generate New Card';
                                    this.tipoAccion= 1;
                                    this.idequipo='';
                                    this.codigo_certificado='';
                                    this.codigo_informe='';
                                    this.fechaIspeccion='';
                                    this.fechaRecomendada='';
                                    this.fechaEmision='';
                                    this.tipoEquipo='';
                                    this.marca='';
                                    this.modeloEquipo='';
                                    this.serie='';
                                    this.capacidad='';
                                    this.ruc='';
                                    this.cliente='';
                                    this.pdsi='';
                                    this.otro='';
                                    break;
                                }
                                case 'actualizar':
                                {
                                    this.tituloModal = 'Preview View';
                                    this.tipoAccion= 2;
                                    this.idequipo=data['id'];
                                    this.codigo_certificado=data['codigo_certificado'];
                                    this.codigo_informe=data['codigo_informe'];
                                    this.fechaIspeccion=data['fechaIspeccion'];
                                    this.fechaRecomendada=data['fechaRecomendada'];
                                    this.fechaEmision=data['fechaEmision'];
                                    this.tipoEquipo=data['tipoEquipo'];
                                    this.marca=data['marca'];
                                    this.modeloEquipo=data['modeloEquipo'];
                                    this.serie=data['serie'];
                                    this.capacidad=data['capacidad'];
                                    this.ruc=data['ruc'];
                                    this.cliente=data['cliente'];
                                    this.pdsi=data['pdsi'];
                                    this.otro=data['otro'];
                                                                    
                                    break;
                                }
                            }
                        }
                }
            }
        },
        mounted() {
           this.listarEquipo(1,this.bpdsi,this.bempresa,this.bnumero,this.bequipo,this.bmodelo,this.bserie);
        }
    }
</script>
<style>
    .modal-content{
        width: 100% !important;
        position: absolute !important;
    }
    .mostrar{
        display: list-item !important;
        opacity: 1 !important;
        position: absolute !important;
        background-color: #3c29297a !important;
    }
    .div-error{
        display: flex;
        justify-content: center;
    }
    .text-error{
        color: red !important;
        font-weight: bold;
    }

</style>