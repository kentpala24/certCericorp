<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0" />

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <title>Validate - CICB LATIN AMERICA</title>
</head>
<style>
    img{
        padding-left: 30%;
    }
    body{
            font-size:15px;  
            background-color: rgb(213, 224, 238);
    }
    div.fondo{
            background-color: rgb(255, 255, 255);
            
    }
    img.esquinas{
        float: right;
    }
    div.alin{
        text-align: right;
    }
    @media only screen and (min-width: 100px) and (max-width: 767px){
        img.esquinas {
            float: right;
            display: none;
            
        }
        img{
            padding-left: 0%;
            width: 100%;
        }
        div.alin{
        text-align: left;
    }
    }
        
</style>
<body>
    <div class="form-group row border">
        <div class="col-md-12 fondo">
            <img src="img/cropped-logo.jpg">
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-1">
            </div>
            <div class="col-md-10 fondo group">

                
                <div class="form-group row">
                    <div class="col-md-12 input-group">
                    <div class="input-group">
                        
                        <div class="col-md-9">
                        <p><br><h4>PROFESIONAL REGISTRADO :</h4></p> 
                        </div>
                        <div class="col-md-3">
                        <br>
                        <img src="img/esquina_arriba_derecha.jpg" class="esquinas">
                        </div>
                        @foreach($certificados as $certificado)
                        <div class="col-md-3 alin">
                        <p>Nombre y Apellidos: &nbsp;</p>
                        </div>
                        <div class="col-md-9">
                        <p><strong>{{$certificado->nombre.' '.$certificado->apellido}}</strong></p>
                        </div>
                        <div class="col-md-3 alin">
                            <p>D.N.I. / Cedula: &nbsp;</p>
                        </div>
                        <div class="col-md-9">
                        <p><strong>{{$certificado->dni}}</strong></p>
                        </div>
                        <div class="col-md-3 alin">
                            <p>Certificación: &nbsp;</p>
                        </div>
                        <div class="col-md-9">
                        <p><strong>{{$certificado->designacion.' '.$certificado->tipo_certificados.': '.$certificado->equipo}}</strong></p>
                        </div>
                        <div class="col-md-3 alin">
                            <p>Nº de Certificado: &nbsp;</p>
                        </div>
                        <div class="col-md-9">
                        <p><strong>P-{{$certificado->certificado}}</strong></p>
                        </div>
                        <div class="col-md-3 alin">
                            <p>Calificación: &nbsp;</p>
                        </div>
                        <div class="col-md-9">
                        <p><strong>{{$certificado->level}}</strong></p>
                        </div>
                        <div class="col-md-3 alin">
                            <p>Vigencia desde: &nbsp;</p>
                        </div>
                        <div class="col-md-9">
                        <p><strong>{{$certificado->fecha_emision7}}</strong> Hasta: <strong>{{$certificado->fecha_expiracion}}</strong></p>
                        </div>
                        <div class="col-md-3 alin">
                            <p>Empresa / Titular: &nbsp;</p>
                        </div>
                        <div class="col-md-9">
                        <p><strong>{{$certificado->empresa}}</strong></p>
                        </div>
                        <div class="col-md-3 alin">
                            <p>Condición: &nbsp;</p>
                        </div>
                        <div class="col-md-9">
                        <p><?php
                        if($certificado->fecha_expiracion>date('Y-m-d')){
                            echo "<strong>VIGENTE</STRONG>";
                        }
                        else{
                            echo "<strong>VENCIDO</STRONG>";
                        }
                        ?></p>
                        </div>
                        <div class="col-md-3 alin">
                            <p>Sede: &nbsp;</p>
                        </div>
                        <div class="col-md-9">
                        <p><strong>Perú</strong></p>
                        </div>
                        <div class="col-md-2 alin">
                            <p></p>
                        </div>
                        <div class="col-md-9">
                            <form action="/search" method="get" >
                                <br><button type="submit" class="btn btn-primary">Volver a Consultar</button><br>
                            </form>
                        </div>
                        @endforeach
                        
                         
                <div class="col-md-9">
                <p><br><br><br><strong>CICB LATIN AMERICA</strong> <br>
                    Para consultar acerca del estado de su certificacion escribir a: <br>
                    <a href = "mailto: serviciospe@cicbla.com">serviciospe@cicbla.com</a><br>
                    o Visite <strong><a href = "https://www.cicbla.com/"> www.cicbla.com</a></strong> <br>
                    Copyright © {{date("Y")}} , All Rights Reserved
                </p> 
                </div>
                <div class="col-md-3"> <br><br>
                <img src="img/pie2.jpg" class="esquinas">
                
                </div>
                </div>
            </div>
        </div>
    </div>
                
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
</body>
</html>