<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Revalidacion extends Model
{
    //
}
