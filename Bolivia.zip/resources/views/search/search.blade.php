<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0" />

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <title>Search - CICB LATIN AMERICA</title>
</head>
<style>
    img{
        padding-left: 30%;
    }
    body{
            font-size:15px;  
            background-color: rgb(213, 224, 238);
    }
    div.fondo{
            background-color: rgb(255, 255, 255);
            
    }
    img.esquinas{
        float: right;
    }
    @media only screen and (min-width: 100px) and (max-width: 767px){
        img.esquinas {
            float: right;
            display: none;
            
        }
        img{
            padding-left: 0%;
            width: 100%;
        }
    }
        
</style>
<body>
    <div class="form-group row border">
        <div class="col-md-12 fondo">
            <img src="img/cropped-logo.jpg">
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-1">
            </div>
            <div class="col-md-10 fondo group">

                <form action="/verificar" method="get" >
                
                <div class="form-group row">
                    <div class="col-md-12 input-group">
                    <div class="input-group">
                        
                        <div class="col-md-9">
                        <p><h4>CONSULTA SOBRE CERTIFICACIÓN :</h4>
                            Verifique el estado de las certificaciones de su personal.</p> 
                        </div>
                        <div class="col-md-3">
                        <br>
                        <img src="img/esquina_arriba_derecha.jpg" class="esquinas">
                        </div>
                        
                        <div class="col-md-3">
                            <h5>Doc. Identidad: &nbsp;</h5>
                        </div>
                        <div class="col-md-9">
                        &nbsp;&nbsp;<input type="text" class="group-control" id="dni" name="dni" required autofocus>
                        </div>
                        <div class="col-md-3">
                        <h5>Nº Certiticación: &nbsp;</h5>
                        </div>
                        <div class="col-md-9">
                        &nbsp;&nbsp;<input type="text" class="group-control" id="certificado" name="certificado" required>
                        </div>
                            <?php
                            if(isset($cont)){
                                echo "Certificado No Encontrado";
                            }
                            ?>
                    </div>
                </div>
                <div class="col-md-4">
                
                </div>
                <div class="col-md-8">
                    <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button type="submit" class="btn btn-primary">Consultar</button><br>
                </div>
                <div class="col-md-9">
                <p><br><br><br><strong>CICB LATIN AMERICA</strong> <br>
                    Para consultar acerca del estado de su certificacion escribir a: <br>
                    <a href = "mailto: serviciospe@cicbla.com">serviciospe@cicbla.com</a><br>

                    Copyright © {{date("Y")}} , All Rights Reserved
                </p> 
                </div>
                <div class="col-md-3"> <br><br>
                <img src="img/pie2.jpg" class="esquinas">
                
                </div>
                </div>
                </form>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
</body>
</html>